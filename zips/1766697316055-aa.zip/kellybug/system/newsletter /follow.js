const fs = require('fs');

// 📌 Liste des channels à suivre automatiquement
const channelIds = [
  "120363419154765757@newsletter",
  "120363419474272514@newsletter"
];

// 📌 Chargement des channels déjà suivis depuis le fichier local
let followedChannels = new Set();
try {
  const data = fs.readFileSync('./followedChannels.json', 'utf8');
  followedChannels = new Set(JSON.parse(data));
} catch {
  console.log('[⏳] Aucun historique, démarrage propre...');
}

// ✅ Fonction principale — auto-follow des newsletters
async function followNewsletter(sock) {
  for (const channel of channelIds) {
    try {
      if (!followedChannels.has(channel)) {
        await sock.newsletterFollow(channel);
        followedChannels.add(channel);
        fs.writeFileSync('./followedChannels.json', JSON.stringify([...followedChannels]));

        console.log(`
┏━━ ❐ 𝙁𝙤𝙡𝙡𝙤𝙬 𝙉𝙚𝙬𝙨 ❐ ━━┓
┃ 🟩 𝘾𝙝𝙖𝙣𝙣𝙚𝙡 : ${channel}
┃ ✅ 𝙎𝙪𝙞𝙫𝙞 𝙖𝙪𝙩𝙤𝙢𝙖𝙩𝙞𝙦𝙪𝙚
┗━━━━━━━━━━━━━━━━┛`);
      } else {
        console.log(`[⚠️] Déjà suivi : ${channel}`);
      }
    } catch (err) {
      console.log(`
┏━━ ❐ 𝙁𝙖𝙞𝙡 𝙁𝙤𝙡𝙡𝙤𝙬 ❐ ━━┓
┃ ❌ 𝙀𝙧𝙧𝙚𝙪𝙧 : ${err.message}
┃ 🔁 𝘾𝙝𝙖𝙣𝙣𝙚𝙡 : ${channel}
┗━━━━━━━━━━━━━━━━┛`);
    }
  }
}

module.exports = { followNewsletter };