// OBEY COMMANDMENTS

global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['50932628598','50955589433']
global.gambar = ""
global.packname = "NINJAXX"
global.author = "NINJAXX"
global.levimenu = "NINJAXX"