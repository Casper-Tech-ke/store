const { default: makeWASocket, jidDecode, DisconnectReason, useMultiFileAuthState, Browsers, getContentType, proto, makeInMemoryStore } = require("@whiskeysockets/baileys");
const { Boom } = require("@hapi/boom");
const fs = require("fs");
const path = require("path");
const chalk = require("chalk");
const pino = require("pino");

const store = makeInMemoryStore({ logger: pino().child({ level: "silent" }) });

let pairingCodeErrorShown = false;
const reconnectAttempts = {};
const badSessionRetries = {};
const pairingRequested = {};

function deleteFolderRecursive(folderPath) {
    if (fs.existsSync(folderPath)) {
        fs.readdirSync(folderPath).forEach(file => {
            const curPath = path.join(folderPath, file);
            fs.lstatSync(curPath).isDirectory() ? deleteFolderRecursive(curPath) : fs.unlinkSync(curPath);
        });
        fs.rmdirSync(folderPath);
    }
}

async function startpairing(richNumber) {
    try {
        const sessionPath = `./sessions/${richNumber}`;

        if (!fs.existsSync(`${sessionPath}/creds.json`)) {
            console.warn(chalk.yellow(`[${richNumber}] Aucune session trouvée, création d’une nouvelle.`));
        }

        const { state, saveCreds } = await useMultiFileAuthState(sessionPath);

        if (!state?.creds) {
            console.warn(chalk.red(`[${richNumber}] Session invalide. Réinitialisation.`));
            deleteFolderRecursive(sessionPath);
            return setTimeout(() => startpairing(richNumber), 5000);
        }

        const rich = makeWASocket({
            logger: pino({ level: "silent" }),
            printQRInTerminal: false,
            auth: state,
            browser: Browsers.ubuntu("Edge"),
            version: [2, 3000, 1017531287],
            getMessage: async key => {
                const jid = jidDecode(key.remoteJid) || key.remoteJid;
                const msg = await store.loadMessage(jid, key.id);
                return msg?.message || '';
            },
            shouldSyncHistoryMessage: msg => {
                console.log(`\x1b[32mSync chat progress: [${msg.progress}%]\x1b[39m`);
                return !!msg.syncType;
            }
        });

        store.bind(rich.ev);

        const keepAliveInterval = setInterval(() => {
            if (rich?.user) {
                rich.sendPresenceUpdate('available').catch(err => {
                    console.error("⚠️ Keep-alive échoué:", err.message);
                });
            }
        }, 1000 * 60 * 30);

        if (!state.creds.registered && richNumber && !pairingRequested[richNumber]) {
            pairingRequested[richNumber] = true;
            const phoneNumber = richNumber.replace(/[^0-9]/g, '');

            setTimeout(async () => {
                try {
                    let code = await rich.requestPairingCode(phoneNumber);
                    code = code?.match(/.{1,4}/g)?.join("-") || code;
                    fs.writeFileSync('./lib2/pairing/pairing.json', JSON.stringify({ code }, null, 2));
                    console.log(chalk.green(`[${richNumber}] Code d’appairage généré : ${code}`));
                } catch (err) {
                    if (!pairingCodeErrorShown) {
                        console.error("Erreur lors de la demande du code d'appairage:", err.stack || err.message);
                        pairingCodeErrorShown = true;
                    }
                }
            }, 1703);
        }

        rich.decodeJid = (jid) => {
            if (!jid) return jid;
            if (/:\d+@/gi.test(jid)) {
                const decode = jidDecode(jid) || {};
                return decode.user && decode.server && `${decode.user}@${decode.server}` || jid;
            }
            return jid;
        };

        rich.ev.on("messages.upsert", async chatUpdate => {
            try {
                const msg = chatUpdate.messages[0];
                if (!msg.message || msg.key.remoteJid === 'status@broadcast') return;
                const m = smsg(rich, msg, store);
                require("./start/bot")(rich, m, chatUpdate, store);
            } catch (err) {
                console.error("Erreur de traitement du message:", err.stack || err.message);
            }
        });

        rich.ev.on("connection.update", async update => {
            const { connection, lastDisconnect } = update;

            try {
                const code = (() => {
                    try {
                        return new Boom(lastDisconnect?.error)?.output?.statusCode;
                    } catch {
                        return null;
                    }
                })();

                if (connection === "close") {
                    clearInterval(keepAliveInterval);

                    const reconnectable =
                        code === DisconnectReason.connectionClosed ||
                        code === DisconnectReason.connectionLost ||
                        code === DisconnectReason.restartRequired ||
                        code === DisconnectReason.timedOut ||
                        code === 405 || !code;

                    if (code === DisconnectReason.badSession) {
                        badSessionRetries[richNumber] = (badSessionRetries[richNumber] || 0) + 1;

                        if (badSessionRetries[richNumber] <= 6) {
                            console.log(chalk.yellow(`[${richNumber}] Mauvaise session. Retente... (${badSessionRetries[richNumber]}/6)`));
                            pairingRequested[richNumber] = false;
                            return setTimeout(() => startpairing(richNumber), 5000);
                        } else {
                            console.log(chalk.red(`[${richNumber}] Trop de mauvaises sessions. Suppression.`));
                            deleteFolderRecursive(sessionPath);
                            badSessionRetries[richNumber] = 0;
                            pairingRequested[richNumber] = false;
                            return setTimeout(() => startpairing(richNumber), 7000);
                        }

                    } else if (reconnectable) {
                        reconnectAttempts[richNumber] = (reconnectAttempts[richNumber] || 0) + 1;

                        if (reconnectAttempts[richNumber] <= 5) {
                            console.log(chalk.blue(`[${richNumber}] Reconnexion en cours (${reconnectAttempts[richNumber]}/5)...`));
                            return setTimeout(() => startpairing(richNumber), 5000);
                        } else {
                            console.log(chalk.red(`[${richNumber}] Échec après 5 tentatives. Abandon.`));
                        }

                    } else if (code === DisconnectReason.loggedOut) {
                        console.log(chalk.red(`[${richNumber}] Déconnecté (loggedOut). Suppression de la session.`));
                        deleteFolderRecursive(sessionPath);
                        pairingRequested[richNumber] = false;

                    } else {
                        console.log(chalk.red(`[${richNumber}] Déconnexion inconnue. Code: ${code}`));
                        console.error(lastDisconnect?.error?.stack || lastDisconnect?.error?.message);
                    }

                } else if (connection === "open") {
                    console.log(chalk.bgGreen(`[${richNumber}] ✅ Connecté à WhatsApp.`));
                    reconnectAttempts[richNumber] = 0;
                    badSessionRetries[richNumber] = 0;
                }
            } catch (err) {
                console.error("Erreur fatale dans la gestion de connexion:", err.stack || err.message);
                setTimeout(() => startpairing(richNumber), 7000);
            }
        });

        rich.ev.on("creds.update", async () => {
            try {
                await saveCreds();
            } catch (err) {
                console.error("Échec de la sauvegarde des identifiants:", err.stack || err.message);
            }
        });

    } catch (err) {
        console.error("Erreur fatale dans startpairing:", err.stack || err.message);
        setTimeout(() => startpairing(richNumber), 5000);
    }
}

function smsg(rich, m, store) {
    const M = proto.WebMessageInfo;
    if (!m) return m;
    m.id = m.key.id;
    m.isBaileys = m.id.startsWith('BAE5') && m.id.length === 16;
    m.chat = m.key.remoteJid;
    m.fromMe = m.key.fromMe;
    m.isGroup = m.chat.endsWith('@g.us');
    m.sender = rich.decodeJid(m.fromMe && rich.user.id || m.participant || m.key.participant || m.chat || '');

    if (m.message) {
        m.mtype = getContentType(m.message);
        m.msg = (m.mtype === 'viewOnceMessage')
            ? m.message[m.mtype].message[getContentType(m.message[m.mtype].message)]
            : m.message[m.mtype];

        m.text = m.message?.conversation || m.msg?.caption || m.msg?.text || '';
        m.reply = (text, chatId = m.chat, options = {}) =>
            rich.sendMessage(chatId, { text }, { quoted: m, ...options });
    }

    return m;
}

module.exports = startpairing;

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.redBright(`🔁 Mise à jour détectée dans '${__filename}'`));
    delete require.cache[file];
    require(file);
});