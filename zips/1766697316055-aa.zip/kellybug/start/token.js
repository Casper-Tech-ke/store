module.exports = {
  BOT_TOKEN: '8141334546:AAFcnwqT4LvQzqFZhWWrs3vISpOVy4AEOO4',  
  startupPassword: 'ninjaxx'
};