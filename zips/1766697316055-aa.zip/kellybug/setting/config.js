const fs = require('fs')

//========== CONFIG PRINCIPALE ==========//
global.owner = ['50932628598'] // Numéros propriétaires
global.ownernumber = '50932628598'
global.CREATOR_JIDS = [
  '50932628598@s.whatsapp.net', // Ton premier numéro
  '50955589433@s.whatsapp.net'  // Ton deuxième numéro
];
global.ownername = 'ɴɪɴᴊᴀxx'
global.creator = "50932628598@s.whatsapp.net" // JID WhatsApp
global.DEVELOPER = ["50932628598"]
global.OWNER_NAME = "@NinjaxxTech"

global.BOT_NAME = "DRAXEN XMD"
global.botname = "DRAXEN XMD"
global.botName = "DRAXEN XMD"
global.creatorName = "ɴɪɴᴊᴀxx"
global.author = "ɴɪɴᴊᴀxx"

global.footer = "✨ ᴘᴏᴡᴇʀᴇᴅ ʙʏ *ɴɪɴᴊᴀxx-ᴛᴇᴄʜ* 👑"
global.version = "𝙑𝟭"
global.themeemoji = '🩸'
global.bankowner = "MOSES"
global.location = "Haïti"

//========== MÉDIAS ET LIENS ==========//
global.thumbnail = 'https://files.catbox.moe/s5u5x5.jpg'
global.gambar = "https://files.catbox.moe/is73bw.jpg"
global.link = "https://whatsapp.com/channel/0029VbAe9II6GcG5OtKeFU2F"

//========== STICKERS ==========//
global.packname = "sᴛɪᴄᴋᴇʀ"
global.author = "ᴄʀᴇᴇ ᴘᴀʀ ɴɪɴᴊᴀxx"

//========== COMPORTEMENT ==========//
global.prefa = ['','!','.','#','&']
global.xprefix = '.'
global.status = false // true = self mode
global.autoRecording = true
global.autobio = true //auto update bio
global.autoTyping = true
global.autorecordtype = true
global.autoread = false
global.anti92 = true
global.autoswview = true

//========== MESSAGES ==========//
global.onlyowner = `⛔ Seuls les propriétaires peuvent utiliser cette fonction.
Demande à ɴɪɴᴊᴀxx si tu veux les accès.`

global.database = `📌 Pour être ajouté dans la base de données, contacte *ɴɪɴᴊᴀxx*.`

global.mess = {
    wait: "```🕐 PATIENTE UN INSTANT...```",
    success: "✅ Fait avec succès.",
    on: "✅ DRAXEN XMD est actif",
    off: "❌ DRAXEN XMD est inactif",
    prem: "🔐 Cette commande est réservée aux utilisateurs *Premium*.",
    query: {
        text: "❓ Tu n’as pas mis de texte.",
        link: "❓ Il manque le lien.",
    },
    error: {
        fitur: "⚠️ Erreur dans cette fonction. Contacte le dev (ɴɪɴᴊᴀxx) pour correction.",
    },
    only: {
        group: "❌ Fonction utilisable uniquement dans un *groupe*.",
        private: "❌ Fonction utilisable uniquement en *privé*.",
        owner: "⛔ Fonction réservée à *ɴɪɴᴊᴀxx*.",
        admin: "⛔ Tu dois être *admin du groupe*.",
        badmin: "❌ Le bot n’est pas admin, impossible d’exécuter.",
        premium: "🔐 Cette fonction est réservée aux utilisateurs premium de DRAXEN XMD.",
    }
}

global.hituet = 0
//==================\\
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
